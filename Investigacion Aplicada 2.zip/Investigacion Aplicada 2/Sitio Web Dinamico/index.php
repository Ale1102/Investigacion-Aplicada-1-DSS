<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'vendor/autoload.php';

use React\Http\HttpServer;
use React\Http\Message\Response;
use React\EventLoop\Factory;
use React\Promise\Promise;

// Crear el bucle de eventos  
$loop = Factory::create();

// Crear servidor HTTP  
$server = new HttpServer(function ($request) {
    $uri = $request->getUri()->getPath();

    switch ($uri) {
        case '/':
            if ($request->getMethod() === 'POST') {
                return handleDataRequest($request);
            }
            return serveHomePage();
        case '/contacto.html':
            return serveContactPage();
        case '/data.json':
            return serveDataAsJson();
        case '/data.html':
            return serveDataAsHtml();
        case '/style.css':
            $cssFile = __DIR__ . '/style.css';
            if (file_exists($cssFile)) {
                return new Response(200, ['Content-Type' => 'text/css'], file_get_contents($cssFile));
            } else {
                return new Response(404, ['Content-Type' => 'text/plain'], "CSS file not found");
            }
        case '/integrantes.html':
            return serveIntegrantesPage();
        default:
            return new Response(404, ['Content-Type' => 'text/plain'], "404 Not Found");
    }
});

// Función para servir la página de inicio  
function serveHomePage()
{
    return new Response(200, ['Content-Type' => 'text/html'], file_get_contents(__DIR__ . '/index.html'));
}

// Función para servir la página de contacto  
function serveContactPage()
{
    return new Response(200, ['Content-Type' => 'text/html'], file_get_contents(__DIR__ . '/contacto.html'));
}

// Función para servir la página de integrantes
function serveIntegrantesPage()
{
    return new Response(200, ['Content-Type' => 'text/html'], file_get_contents(__DIR__ . '/integrantes.html'));
}

// Función para servir datos en formato JSON
function serveDataAsJson()
{
    $file = __DIR__ . '/data.json';
    if (!file_exists($file)) {
        return new Response(404, ['Content-Type' => 'application/json'], json_encode(['error' => 'Data file not found']));
    }

    $data = file_get_contents($file);
    return new Response(200, ['Content-Type' => 'application/json'], $data);
}

// Función para servir datos en formato HTML
function serveDataAsHtml()
{
    $file = __DIR__ . '/data.json';
    if (!file_exists($file)) {
        return new Response(
            404,
            ['Content-Type' => 'text/html'],
            '<div class="error">No se encontró el archivo de datos</div>'
        );
    }

    $data = json_decode(file_get_contents($file), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return new Response(
            500,
            ['Content-Type' => 'text/html'],
            '<div class="error">Error: Formato JSON inválido</div>'
        );
    }

    if (empty($data)) {
        return new Response(
            200,
            ['Content-Type' => 'text/html'],
            '<div class="info">No hay registros disponibles</div>'
        );
    }

    $html = '<div class="data-grid">';
    foreach ($data as $entry) {
        $html .= sprintf(
            '<div class="data-item">' .
                '<div class="data-field"><strong>Nombre:</strong> %s</div>' .
                '<div class="data-field"><strong>Email:</strong> %s</div>' .
                '</div>',
            htmlspecialchars($entry['name']),
            htmlspecialchars($entry['email'])
        );
    }
    $html .= '</div>';

    return new Response(200, ['Content-Type' => 'text/html'], $html);
}

// Manejo de datos  
function handleDataRequest($request)
{
    if ($request->getMethod() === 'POST') {
        return $request->getBody()->then(function ($body) {
            $data = json_decode($body, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return new Response(400, ['Content-Type' => 'application/json'], json_encode(['error' => 'Invalid JSON format']));
            }
            return createData($data);
        });
    } elseif ($request->getMethod() === 'GET') {
        return getData();
    }
    return new Response(400, ['Content-Type' => 'text/plain'], 'Invalid request');
}

// Función para obtener datos  
function getData()
{
    $file = __DIR__ . '/data.json';
    if (!file_exists($file)) {
        return new Response(404, ['Content-Type' => 'application/json'], json_encode(['error' => 'Data file not found']));
    }

    $data = file_get_contents($file);
    return new Response(200, ['Content-Type' => 'application/json'], $data);
}

// Función para crear datos nuevos (POST)  
function createData($data)
{
    if (empty($data['name']) || empty($data['email'])) {
        return new Response(400, ['Content-Type' => 'application/json'], json_encode(['error' => 'Invalid input']));
    }

    $file = __DIR__ . '/data.json';

    // Inicializar archivo con un arreglo vacío si no existe
    if (!file_exists($file)) {
        file_put_contents($file, json_encode([]));
    }

    // Leer datos existentes
    $existingData = json_decode(file_get_contents($file), true) ?: [];

    // Agregar los datos enviados
    $newData = [
        'name' => $data['name'],
        'email' => $data['email']
    ];
    $existingData[] = $newData;

    // Guardar datos en formato JSON
    if (file_put_contents($file, json_encode($existingData, JSON_PRETTY_PRINT))) {
        return new Response(201, ['Content-Type' => 'application/json'], json_encode(['message' => 'Data created', 'data' => $newData]));
    } else {
        return new Response(500, ['Content-Type' => 'application/json'], json_encode(['error' => 'Failed to save data']));
    }
}

// Función para actualizar datos existentes (PUT)  
function updateData($data)
{
    if (empty($data['id']) || empty($data['name']) || empty($data['email'])) {
        return new Response(400, ['Content-Type' => 'application/json'], json_encode(['error' => 'Invalid input']));
    }

    $file = __DIR__ . '/data.json';
    $existingData = json_decode(file_get_contents($file), true);

    foreach ($existingData as &$entry) {
        if ($entry['id'] === $data['id']) {
            $entry['name'] = $data['name'];
            $entry['email'] = $data['email'];
            file_put_contents($file, json_encode($existingData));
            return new Response(200, ['Content-Type' => 'application/json'], json_encode(['message' => 'Data updated']));
        }
    }

    return new Response(404, ['Content-Type' => 'application/json'], json_encode(['error' => 'Data not found']));
}

// Función para eliminar datos existentes (DELETE)  
function deleteData($data)
{
    if (empty($data['id'])) {
        return new Response(400, ['Content-Type' => 'application/json'], json_encode(['error' => 'Invalid input']));
    }

    $file = __DIR__ . '/data.json';
    $existingData = json_decode(file_get_contents($file), true);

    $filteredData = array_filter($existingData, function ($entry) use ($data) {
        return $entry['id'] !== $data['id'];
    });

    if (count($filteredData) === count($existingData)) {
        return new Response(404, ['Content-Type' => 'application/json'], json_encode(['error' => 'Data not found']));
    }

    file_put_contents($file, json_encode(array_values($filteredData)));
    return new Response(200, ['Content-Type' => 'application/json'], json_encode(['message' => 'Data deleted']));
}

// Escuchar en el puerto 8081 
try {
    $socket = new React\Socket\SocketServer('127.0.0.1:8081', [], $loop);
    $server->listen($socket);
    echo "Servidor escuchando en http://127.0.0.1:8081\n";
    $loop->run();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

// Iniciar el bucle de eventos  
$loop->run();
